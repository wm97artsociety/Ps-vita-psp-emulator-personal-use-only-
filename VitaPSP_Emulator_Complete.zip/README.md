# VitaPSP Emulator Project

Details inside.
